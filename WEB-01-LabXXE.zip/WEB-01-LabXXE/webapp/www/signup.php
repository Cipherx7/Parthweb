<?php
include 'db.php';
$message = '';
$message_type = ''; // Will be 'success' or 'error'

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Prepare a statement to check if the username already exists
    $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Username is already taken
        $message = 'Error: This username is already taken.';
        $message_type = 'error';
    } else {
        // Username is available, proceed with insertion
        $stmt_insert = $conn->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
        $stmt_insert->bind_param("ss", $username, $password);

        if ($stmt_insert->execute()) {
            $message = 'Registration successful! You can now <a href="login.php" class="font-bold">login</a>.';
            $message_type = 'success';
        } else {
            $message = 'Error: ' . $stmt_insert->error;
            $message_type = 'error';
        }
        $stmt_insert->close();
    }
    $stmt->close();
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sign Up</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 flex items-center justify-center h-screen">
    <div class="w-full max-w-md bg-white p-8 rounded-lg shadow-md">
        <h1 class="text-3xl font-bold text-center text-gray-800 mb-6">Create Account</h1>
        <form action="signup.php" method="POST">
            <div class="mb-4">
                <label for="username" class="block text-gray-700 font-semibold mb-2">Username:</label>
                <input type="text" id="username" name="username" required class="w-full p-3 border rounded-md">
            </div>
            <div class="mb-6">
                <label for="password" class="block text-gray-700 font-semibold mb-2">Password:</label>
                <input type="password" id="password" name="password" required class="w-full p-3 border rounded-md">
            </div>
            <button type="submit" class="w-full bg-indigo-500 text-white p-3 rounded-md hover:bg-indigo-600">Sign Up</button>
        </form>
        <p class="text-center text-gray-500 mt-4">Already have an account? <a href="login.php" class="text-indigo-500 hover:underline">Login here</a>.</p>
        <?php
        // Display the success or error message from the registration attempt
        if (!empty($message)) {
            $color_class = ($message_type === 'success') ? 'green' : 'red';
            echo "<div class='mt-4 text-center p-3 rounded-md text-{$color_class}-700 bg-{$color_class}-100'>{$message}</div>";
        }
        ?>
    </div>
</body>
</html>
