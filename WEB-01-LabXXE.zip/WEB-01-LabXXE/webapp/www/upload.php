<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: login.php');
    exit;
}

// --- NEW: Define the taunting messages ---
$taunts = [
    "Payload ingested. Checking for anomalies...",
    "File signature does not match known patterns. Escalating for review.",
    "Data assimilated. You will be notified if we need more... information.",
    "Entry quarantined for deeper analysis.",
    "Processing... System integrity is our priority."
];

if (isset($_FILES['resume']) && $_FILES['resume']['error'] === UPLOAD_ERR_OK) {
    $user_dir = 'uploads/' . $_SESSION['id'];
    // This check is good practice even with the Dockerfile fix
    if (!is_dir($user_dir)) {
        mkdir($user_dir, 0755, true);
    }

    $upload_file = $user_dir . '/' . basename($_FILES['resume']['name']);
    
    if (move_uploaded_file($_FILES['resume']['tmp_name'], $upload_file)) {
        $xml_content = file_get_contents($upload_file);

        // --- THE VULNERABILITY ---
        libxml_use_internal_errors(true);
        $doc = simplexml_load_string($xml_content, 'SimpleXMLElement', LIBXML_NOENT);

        if ($doc === false) {
            // This is a real error for a malformed XML file
            header('Location: index.php?status=error');
        } else {
            // --- MODIFIED: Redirect with a random taunt ID ---
            // The file was "processed", so we trigger the taunt sequence
            $taunt_id = array_rand($taunts);
            header('Location: index.php?status=processed&tid=' . $taunt_id);
        }
    } else {
        header('Location: index.php?status=error');
    }
} else {
    header('Location: index.php?status=error');
}
exit;
?>
