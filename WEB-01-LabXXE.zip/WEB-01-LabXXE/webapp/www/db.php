<?php
$servername = "db";
$username = "user";
$password = "password";
$dbname = "ctf_lab";

// Create a single, direct connection attempt.
$conn = new mysqli($servername, $username, $password, $dbname);

// If the connection fails for any reason, stop execution immediately.
// This is robust because the healthcheck should prevent this from ever happening
// during startup.
if ($conn->connect_error) {
    // Use error_log for server-side errors instead of echoing to the user.
    error_log("Database connection failed: " . $conn->connect_error);
    // Provide a generic error to the user without revealing details.
    die("Error: Unable to connect to the service. Please try again later.");
}

// Create the users table if it doesn't already exist.
$conn->query("CREATE TABLE IF NOT EXISTS users (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)");
?>
