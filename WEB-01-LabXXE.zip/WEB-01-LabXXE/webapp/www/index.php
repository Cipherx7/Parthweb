<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: login.php');
    exit;
}

// --- NEW: Define the same taunting messages as in upload.php ---
// In a real app, this would be in a shared config file.
$taunts = [
    "Payload ingested. Checking for anomalies...",
    "File signature does not match known patterns. Escalating for review.",
    "Data assimilated. You will be notified if we need more... information.",
    "Entry quarantined for deeper analysis.",
    "Processing... System integrity is our priority."
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>HR Resume Portal</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 flex items-center justify-center h-screen">
    <div class="w-full max-w-lg bg-white p-8 rounded-lg shadow-md">
        <div class="flex justify-between items-center mb-6">
            <h1 class="text-2xl font-bold text-gray-800">Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h1>
            <a href="logout.php" class="bg-red-500 text-white py-2 px-4 rounded-md hover:bg-red-600">Logout</a>
        </div>
        <h2 class="text-3xl font-bold text-center text-gray-800 mb-2">Submit Your Resume</h2>
        <p class="text-center text-gray-500 mb-6">Our new automated system processes industry-standard XML resumes.</p>
        <form action="upload.php" method="POST" enctype="multipart/form-data">
            <div class="mb-4">
                <label for="resume-file" class="block text-gray-700 font-semibold mb-2">Resume File (.xml):</label>
                <input type="file" id="resume-file" name="resume" accept=".xml" required class="w-full p-3 border rounded-md file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100">
            </div>
            <button type="submit" class="w-full bg-indigo-500 text-white p-3 rounded-md hover:bg-indigo-600">Submit Application</button>
        </form>
        <div id="result" class="mt-4 text-center p-3 rounded-md">
            <?php if (isset($_GET['status'])): ?>
                <?php if ($_GET['status'] === 'error'): ?>
                    <p class="text-red-700 bg-red-100 p-3 rounded-md">Error: Invalid file format or server error.</p>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>

    <?php
    // --- NEW: Check for the 'processed' status to trigger the JavaScript sequence ---
    if (isset($_GET['status']) && $_GET['status'] === 'processed' && isset($_GET['tid'])) {
        $taunt_id = (int)$_GET['tid'];
        // Ensure the taunt ID is valid before using it
        if (isset($taunts[$taunt_id])) {
            $taunt_message = $taunts[$taunt_id];
            
            // This block injects the JavaScript into the page
            echo '<script>
                const resultDiv = document.getElementById("result");
                const tauntMessage = ' . json_encode($taunt_message) . ';

                // Stage 1: Display the fake error message immediately
                resultDiv.innerHTML = `<p class="text-red-700 bg-red-100 p-3 rounded-md">Upload rejected. Invalid file signature detected.</p>`;

                // Stage 2: After 2.5 seconds, replace it with the real taunt
                setTimeout(() => {
                    resultDiv.innerHTML = `<p class="text-blue-700 bg-blue-100 p-3 rounded-md">${tauntMessage}</p>`;
                }, 2500); // 2500 milliseconds = 2.5 seconds
            </script>';
        }
    }
    ?>
</body>
</html>
