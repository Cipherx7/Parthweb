<?php
// Start the session at the very beginning of the script
session_start();

// If the user is already logged in, redirect them to the main page
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
    header('location: index.php');
    exit;
}

// Include the database connection
include 'db.php';

// Define a variable to hold error messages
$error_message = '';

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, password FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        // Verify the hashed password
        if (password_verify($password, $row['password'])) {
            // Password is correct, start a new session and save user data
            $_SESSION['loggedin'] = true;
            $_SESSION['id'] = $row['id'];
            $_SESSION['username'] = $username;
            
            // Redirect to the main portal page
            header("location: index.php");
            exit; // Stop script execution after redirect
        } else {
            // Set an error message for an invalid password
            $error_message = "Error: Invalid password.";
        }
    } else {
        // Set an error message for a non-existent user
        $error_message = "Error: No user found with that username.";
    }
    $stmt->close();
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 flex items-center justify-center h-screen">
    <div class="w-full max-w-md bg-white p-8 rounded-lg shadow-md">
        <h1 class="text-3xl font-bold text-center text-gray-800 mb-6">Login</h1>
        <form action="login.php" method="POST">
            <div class="mb-4">
                <label for="username" class="block text-gray-700 font-semibold mb-2">Username:</label>
                <input type="text" id="username" name="username" required class="w-full p-3 border rounded-md">
            </div>
            <div class="mb-6">
                <label for="password" class="block text-gray-700 font-semibold mb-2">Password:</label>
                <input type="password" id="password" name="password" required class="w-full p-3 border rounded-md">
            </div>
            <button type="submit" class="w-full bg-indigo-500 text-white p-3 rounded-md hover:bg-indigo-600">Login</button>
        </form>
        <p class="text-center text-gray-500 mt-4">Don't have an account? <a href="signup.php" class="text-indigo-500 hover:underline">Sign up here</a>.</p>
        <?php 
        // Display the error message if one was set
        if (!empty($error_message)) {
            echo '<p class="text-red-700 bg-red-100 p-3 rounded-md mt-4">' . htmlspecialchars($error_message) . '</p>';
        }
        ?>
    </div>
</body>
</html>
